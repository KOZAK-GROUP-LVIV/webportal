import { Component, OnInit, Inject } from '@angular/core';
import { httpConnection } from '../tokens'
import { Router } from '@angular/router';



@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  private user;
  private isAuth:boolean = false;

  constructor(@Inject(httpConnection) private _http, private _route:Router) {
  	this._http.authStream.subscribe(user=>{
  			this.user = user;
  			this.isAuth = true;
  	});

  

   }




   private logout(){
   	this._http.logout().suscribe(()=>{
   		this.isAuth = false;
   		this._route.navigate(['/entry', 'login']);
   	},
   	()=>{

   	});

   }

  ngOnInit() {
  }

}
