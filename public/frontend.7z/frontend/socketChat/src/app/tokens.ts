import  {OpaqueToken} from "@angular/core";

export const httpConnection = new OpaqueToken('httpConnection');
export const socketConnection = new OpaqueToken('socketConnection');