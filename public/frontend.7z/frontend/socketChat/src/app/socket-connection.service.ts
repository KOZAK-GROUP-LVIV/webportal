import { Injectable } from '@angular/core';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import {Subject} from 'rxjs/Subject';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';
import 'rxjs/add/observable/from';
import 'rxjs/add/observable/merge';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/fromPromise'
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mapTo';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/switchMapTo';
import 'rxjs/add/operator/takeWhile';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';



import * as io  from 'socket.io-client';



@Injectable()
export class SocketConnectionService {

  public friendsListExample = {
    friends: [{first_name:'Uriy', last_name:'Grysuk', login:'Ura123', _id: 123},
              {first_name:'Denya', last_name:'Astahov', login:'Denya123', _id:1234},
              {first_name:'Dmitry', last_name:'Dudik', login:'Dmitry123', _id:12345}]
  }

  public frientsHistoty = {
    123 : [{}],
    1234 : [{}],
    12345 : [{}]
  }


  public socket;

  constructor() {
     
  	this.socket = io('127.0.0.1:3000');
    this.socket.on('connect', ()=>{
         this.socket.on('getUser', function(user){
        console.log(user);
        this.socket.emit('getUser');
    });
    });
	
   }

   public getFriendsList(){
     return Observable.create((observer:Observer<any>)=>{
         observer.next(this.friendsListExample.friends)
     });
   }

   public getFriendList(idUser:number){
    

   }
   public getPersonHistory(idUser:number, pages:number){

   }
   public sendMsg(dataActionMsg){

   }

}
