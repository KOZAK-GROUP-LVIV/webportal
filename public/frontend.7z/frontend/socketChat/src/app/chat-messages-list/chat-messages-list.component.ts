import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-messages-list',
  templateUrl: './chat-messages-list.component.html',
  styleUrls: ['./chat-messages-list.component.css']
})
export class ChatMessagesListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
