import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import {socketConnection} from '../tokens'
@Component({
  selector: 'app-chat-list',
  templateUrl: './chat-list.component.html',
  styleUrls: ['./chat-list.component.css']
})
export class ChatListComponent implements OnInit {

  private friendList;
  private checkoutFriend;
  private currFriend;


  @ViewChild('msgList')
  	private msgList;

  constructor(@Inject(socketConnection) private _socket) {
 	this.getFriendList();

 }


  private getFriendList(){
  	this._socket.getFriendsList().subscribe(friends=>{
  		this.friendList = friends;
  	});
  }


  private checkFriend(user){
  	this.msgList.currId = user.id;
  	this.msgList.getHistory(user.id);
  	this.msgList.currUser = user;
  	this.currFriend = user;

  }

  ngOnInit() {

  }

}
