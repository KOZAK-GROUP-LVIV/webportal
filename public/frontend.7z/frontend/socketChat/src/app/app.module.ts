import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Route, RouterModule } from '@angular/router';

import {httpConnection, socketConnection} from './tokens';
import {HttpConnectionService} from './http-connection.service';
import {SocketConnectionService} from './socket-connection.service';

import { AppComponent } from './app.component';
import { ChatListComponent } from './chat-list/chat-list.component';
import { ChatMessagesListComponent } from './chat-messages-list/chat-messages-list.component';
import { EntryComponent } from './entry/entry.component';
import { CookieLawModule } from 'angular2-cookie-law';
import { NavComponent } from './nav/nav.component';
 
const routers:Route[] = [
{path: 'entry/:mode', component: EntryComponent},
{path: 'chat', component: ChatListComponent},
{path: 'chat/:id', component: ChatListComponent},
{path: '**', redirectTo: 'entry/login'}]

@NgModule({
  declarations: [
    AppComponent,
    ChatListComponent,
    ChatMessagesListComponent,
    EntryComponent,
    NavComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    CookieLawModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routers)
  ],
  providers: [{provide: httpConnection, useClass: HttpConnectionService}, 
              {provide: socketConnection, useClass: SocketConnectionService}],
  bootstrap: [AppComponent]
})
export class AppModule { }
